library(dplyr)
library(tidyr)
library(lubridate)

setwd("C:/Users/dingjunjie/Desktop/ML")
doc<-read.table("household_power_consumption.txt",sep=";",header = TRUE,stringsAsFactors = FALSE)
doc2<-doc%>%filter(Date %in% c("1/2/2007","2/2/2007"))

doc2$Date<-as.Date(doc2$Date,"%d/%m/%Y")
doc2$Time<-strptime(paste(doc2$Date,doc2$Time),"%Y-%m-%d %H:%M:%S")
doc2$Global_active_power<-as.numeric(doc2$Global_active_power)
doc2$Global_reactive_power<-as.numeric(doc2$Global_reactive_power)
doc2$Voltage<-as.numeric(doc2$Voltage)
doc2$Global_intensity<-as.numeric(doc2$Global_intensity)
doc2$Sub_metering_1<-as.numeric(doc2$Sub_metering_1)
doc2$Sub_metering_2<-as.numeric(doc2$Sub_metering_2)
doc2$Sub_metering_3<-as.numeric(doc2$Sub_metering_3)

#plot4
png(file="plot4.png", bg="transparent")
par(mfrow=c(2,2))
plot(doc2$Time,doc2$Global_active_power,type="l",xlab="",ylab="Global Active Power(kilowatts)")
plot(doc2$Time,doc2$Voltage,type="l",xlab="datetime",ylab="Voltage")
plot(doc2$Time,doc2$Sub_metering_1,type="l",xlab="",ylab="Energy sub metering")
lines(doc2$Time,doc2$Sub_metering_2,col="red")
lines(doc2$Time,doc2$Sub_metering_3,col="blue")
legend("topright",c("Sub_metering_1","Sub_metering_2","Sub_metering_3"),col=c("black","red","blue"),lty=1,bty="n")
plot(doc2$Time,doc2$Global_reactive_power,type="l",xlab="datetime",ylab="Global_reactive_power")
dev.off()



